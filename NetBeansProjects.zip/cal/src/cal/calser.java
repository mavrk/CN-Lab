package cal;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket; 
import java.util.StringTokenizer;
 
public class calser
{
    public static void main(String args[]) throws IOException
    {
 
        ServerSocket ss = new ServerSocket(3000);
        Socket s = ss.accept();
 
        DataInputStream dis = new DataInputStream(s.getInputStream());
        DataOutputStream dos = new DataOutputStream(s.getOutputStream());
        int i = 0;
 
        while (i < 20)
        {
            String input = dis.readUTF();
 
            System.out.println("Equation received:-" + input);
            double result;
 
            StringTokenizer st = new StringTokenizer(input);
 
            double oprnd1 = Double.parseDouble(st.nextToken());
            String operation = st.nextToken();
            double oprnd2 = Double.parseDouble(st.nextToken());
 
            // perform the required operation.
            if (operation.equals("+"))
            {
                result = oprnd1 + oprnd2;
            }
 
            else if (operation.equals("-"))
            {
                result = oprnd1 - oprnd2;
            }
            else if (operation.equals("*"))
            {
                result = oprnd1 * oprnd2;
            }
            else
            {
                result = oprnd1 / oprnd2;
            }
            System.out.println("Sending the result...");
 
            dos.writeUTF(Double.toString(result));
            i++;
        }
    }
}