import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class Sliding extends Applet implements ActionListener, Runnable{

	Canvas1 canvas;
	Help helpframe;
	Button start, stop1, pause, options, helpbutton;
	menu choice;
	Thread current = null;
	boolean paused = true;
	int AtoB = 1;    //Current direction of transfer
	int delay = 0;
	int maxseq = 7;
	int initdir = 1;  //Who goes first?
	int type = 0;     //0 => ideal
	int lossnoa = 3;
	int lossnob = 3;
	boolean randomloss = false;


	public String getAppletInfo(){
		return "Project Title :- Tools for Network and Protocol Simulation"
			+ "\r\n\n"
			+ "Group Members :- \r\n"
			+ "\t1.Manish Kumar Garg\r\n"
			+ "\t2.Ramesh Soni\r\n";
		}

	public void init(){				     //Applet initializations.
		setBackground(Color.lightGray);
		setSize(640, 464);
		add(canvas = new Canvas1(initdir));
		canvas.setSize(640, 384);
		choice = new menu("  *  Simulation Parameters  *  ");
		choice.setSize(500, 400);
		choice.setLocation(70, 25);
		helpframe = new Help("Help");
		add(start   = new Button("  Start  ")); //Add control buttons.
		add(stop1   = new Button("  Stop   "));
		add(pause   = new Button("  Pause  "));
		add(options = new Button(" Change Settings "));
		add(helpbutton    = new Button("  Help  "));
		start.addActionListener(this);
		stop1.addActionListener(this);
		pause.addActionListener(this);
		options.addActionListener(this);
		helpbutton.addActionListener(this);
		stop1.setEnabled(false);            //Initially only the 'Start'
		pause.setEnabled(false);			 //button is enabled.
		}


		//The method actionPerformed() passes control to the
		//approprite event handler.

	public void actionPerformed(ActionEvent event){
		if (event.getSource() == start){
			if (helpframe.isVisible()){
				helpframe.setVisible(false);
				canvas.sim = false;
				canvas.packet.clear = true;
				canvas.packet.active = false;
				canvas.repaint();
				}
			Start();
			}
		if (event.getSource() == stop1){
			Stops();
			}
		if (event.getSource() == pause){
			PauseorResume();
			}
		if (event.getSource() == options){
			if (options.getLabel() .equals(" Change Settings ")){
				options.setLabel("  Done  ");
				choice.setVisible(true);
				start.setEnabled(false);
				}
			else {
				choice.setVisible(false);
				options.setLabel(" Change Settings ");
				//canvas.first = 0;
				canvas.sim = false;
				canvas.packet.clear = true;
				canvas.packet.active = false;
				canvas.repaint();

				lossnoa = choice.getlossnoa();
				lossnob = choice.getlossnob();
				randomloss = choice.israndom();
				canvas.setlossno(lossnoa, lossnob, randomloss);
				delay = choice.getdelay();
				type = choice.gettype();
				canvas.settype(type);
				maxseq = choice.getmaxseq();

//				canvas.packet.A.setmaxseq(maxseq);
//				canvas.packet.B.setmaxseq(maxseq);

				canvas.setmaxseq(maxseq);
				initdir = choice.getinitdir();
				AtoB = initdir;
				canvas.packet.setinitdir(initdir);
				start.setEnabled(true);
				}
			}
		if (event.getSource() == helpbutton){
			 helpframe.setSize(590, 410);
			 helpframe.show();
			}
		}


	private void Start(){                    //Start simulation.
		start.setEnabled(false);
		stop1.setEnabled(true);
		options.setEnabled(false);
		helpbutton.setEnabled(false);
		pause.setLabel(" Pause ");
		pause.setEnabled(true);
		paused = false;
		canvas.packet.active = true;
		canvas.packet.A.reset();
		canvas.packet.B.reset();
		canvas.packet.sendinit();
		canvas.packet.clear = false;
		canvas.sim = true;
		//AtoB = 1;
		AtoB = initdir;
		start();
		}

	private void Stops(){                    //Stop and reset simulation.
		//canvas.first = 0;
		canvas.sim = false;
		canvas.packet.clear = true;
		canvas.packet.active = false;
		canvas.repaint();
		if (current != null)
			current.stop();
		current = null;
		paused = true;
		stop1.setEnabled(false);
		start.setEnabled(true);
		options.setEnabled(true);
		helpbutton.setEnabled(true);
		pause.setLabel(" Pause ");
		pause.setEnabled(false);
		}

	private void PauseorResume(){            //Freeze or resume simulation.
		if (pause.getLabel() .equals(" Pause ")){
			if (current != null) {
				paused = true;
				current.suspend();
				Graphics g = getGraphics();
				canvas.packet.drawpacket(g,
				canvas.packet.getx(), canvas.packet.gety());
				}
			helpbutton.setEnabled(true);
			pause.setLabel("Resume");
			}
		else {
			pause.setLabel(" Pause ");
			helpbutton.setEnabled(false);
			paused = false;
			current.resume();
			}
		}

	public void start(){                     //Create a new thread.
		if (paused){
			}
		else{
			if (current == null){
				current = new Thread(this);
				current.setPriority(Thread.MIN_PRIORITY);
				current.start();
				}
			}
		}

	public void stop(){                      //Destroy the thread.
		current = null;
		}

	public void run(){                       //Thread control method.
		long startTime = System.currentTimeMillis();

		while (Thread.currentThread() == current){
			if (!paused) {
				canvas.repaint();
				}
			try{
			    //startTime = startTime + 30;
			    //Thread.yield();
			    Thread.sleep(delay);
			    //Thread.sleep(Math.max(0, startTime - System.currentTimeMillis()));
			    }
			catch(InterruptedException e){}
			if (canvas.packet.nextxy(AtoB) == -1){

			 //Change the direction of data transfer.
				try {
					Thread.sleep(800);
					}
				catch(InterruptedException e){};
				changedir();
				}
			}
		}

	void changedir(){
		if (AtoB == 1) AtoB = 0;   //reverse direction.
			else 	AtoB = 1;
		canvas.erase = 0;
		canvas.packet.clear = true;
		canvas.repaint();
		canvas.packet.changeturn();
		canvas.packet.clear = false;
		}
	}

class Canvas1 extends Canvas{
	Packet packet;
	Font font ;
	FontMetrics fontm;
	String text = "Sliding Window Protocol Simulation.";
	String sendm = "Sending Window";
	String recm = "Receiving Window";
//	public int first = 0;    //used only once for drawing the top windows.
	int maxseq = 7;
	int type = 0;
	int lossnoa = 3;
	int lossnob = 3;
	boolean randomloss = false;
	boolean sim = false;
	int erase = 0;

	Canvas1(int initdir){
		super();
//		packet = new Packet(50, 200);
		packet = new Packet(initdir);
		}

	public void settype(int type){
		this.type = type;
		packet.settype(type);
		}

	public void setlossno(int lossnoa, int lossnob, boolean randomloss){
		this.lossnoa = lossnoa;
		this.lossnob = lossnob;
		this.randomloss = randomloss;
		packet.setlossno(lossnoa, lossnob, randomloss);
		}

	public void setmaxseq(int maxseq){
		this.maxseq = maxseq;
		packet.setmaxseq(maxseq);
		}

	public void paint(Graphics g){
	//if (first == 0){
	if (sim == false) {
		g.setFont(font = new Font("Times New Roman", Font.PLAIN | Font.BOLD, 14));
		fontm = getFontMetrics(font);
		Dimension d = getSize();
		g.setColor(Color.black);
		g.drawString(text, (d.width - fontm.stringWidth(text))/2, 10);

		g.setFont(font = new Font("Times New Roman", Font.PLAIN | Font.BOLD, 12));
		g.drawString(sendm, 200 - fontm.stringWidth(sendm)/2 + 15, 97);
		g.drawString(recm, 400 - fontm.stringWidth(recm)/2 + 15, 97);
		g.drawString(recm, 200 - fontm.stringWidth(recm)/2 + 15, 380);
		g.drawString(sendm, 400 - fontm.stringWidth(sendm)/2 + 15, 380);


		g.setColor(getBackground());
		g.fill3DRect(5, 29, 155 , 49, true);
		g.fill3DRect(495, 40, 120 , 30, true);
		g.setColor(Color.green);
		g.fill3DRect(20, 34, 6, 7, true);
		g.setColor(Color.pink);
		g.fill3DRect(20, 49, 6, 7, true);
		g.setColor(Color.gray);
		g.fill3DRect(10, 64, 16, 7, true);
		g.setColor(Color.red);
		g.fillArc(500, 50, 10, 10, 270, 180);
		g.setColor(Color.black);
		g.drawOval(500 , 50 , 10, 10);
		g.drawLine(505, 48, 505, 52);
		g.drawLine(505, 58, 505, 62);

		g.setFont(new Font("Times New Roman", Font.PLAIN, 10));
		g.setColor(Color.black);
		int maxbit = 1;
		switch (maxseq){
			case 1 : maxbit = 1;
				    break;
			case 3 : maxbit = 2;
				    break;
			case 7 : maxbit = 3;
				    break;
			default :break;
			}
		g.drawString(String.valueOf(maxbit) + "-bit sequence no.", 30, 41);
		g.drawString(String.valueOf(maxbit) + "-bit acknowledgement no.", 30, 56);
		g.drawString("The actual data packet.", 30, 71);
		g.drawString("The active window.",515, 58);

		g.setColor(getBackground());
		g.draw3DRect(5, 29, 155 , 49, true);
		g.draw3DRect(495, 40, 120 , 30, true);
		g.fill3DRect(40, 180, 520, 8, true);  //A
		g.fill3DRect(40, 280, 520, 8, true);  //B
		g.fill3DRect(298, 90, 3, 85, true);  //vertical lines
		g.fill3DRect(298, 293, 3, 85, true);



		g.setFont(font = new Font("Times New Roman", Font.PLAIN, 9));
		fontm = getFontMetrics(font);
		g.setColor(Color.black);
		g.drawString("A", 565, 187);
		g.drawString("B", 565, 287);
		erase = 0;
	   }
		g.setFont(font = new Font("Times New Roman", Font.PLAIN, 9));
		if (!packet.clear){
			packet.sendpacket(g, packet.getx(), packet.gety(), erase);
			}
		else {
			g.setColor(Color.lightGray);
			g.fillRect(40, 189, 520, 90);
			if (packet.turn == 0 || sim == false){
				g.fill3DRect(200 - 45, 140 - 35, 90, 70, true);
				g.fill3DRect(400 - 45, 140 - 35, 90, 70, true);
				}
			if (packet.turn == 1 || sim == false){
				g.fill3DRect(200 - 45, 328 - 35, 90, 70, true);
				g.fill3DRect(400 - 45, 328 - 35, 90, 70, true);
				}
			g.setColor(Color.black);
			packet.drawCircle(g, 200, 140, 25, 270, 0, true);
			packet.drawCircle(g, 400, 140, 25, 270, 0, true);
			packet.drawCircle(g, 200, 328, 25, 90, 0, true);
			packet.drawCircle(g, 400, 328, 25, 90, 0, true);
			g.setFont(font = new Font("Times New Roman", Font.PLAIN, 10));

			switch (maxseq){
				case 1 :
						g.drawString("0",200 + 31, 140 + 3);
						g.drawString("0",400 + 31, 140 + 3);
						g.drawString("0",200 + 31, 328 + 3);
						g.drawString("0",400 + 31, 328 + 3);
						g.drawString("1",200 - 35, 140 + 3);
						g.drawString("1",400 - 35, 140 + 3);
						g.drawString("1",200 - 35, 328 + 3);
						g.drawString("1",400 - 35, 328 + 3);
						break;
				case 3 :
						g.drawString("0",200 + 26, 140 + 3 - 20);
						g.drawString("0",400 + 26, 140 + 3 - 20);
						g.drawString("0",200 + 26, 328 + 3 - 20);
						g.drawString("0",400 + 26, 328 + 3 - 20);
						g.drawString("1",200 + 26, 140 + 3 + 20);
						g.drawString("1",400 + 26, 140 + 3 + 20);
						g.drawString("1",200 + 26, 328 + 3 + 20);
						g.drawString("1",400 + 26, 328 + 3 + 20);
						g.drawString("2",200 - 30, 140 + 3 + 20);
						g.drawString("2",400 - 30, 140 + 3 + 20);
						g.drawString("2",200 - 30, 328 + 3 + 20);
						g.drawString("2",400 - 30, 328 + 3 + 20);
						g.drawString("3",200 - 30, 140 + 3 - 20);
						g.drawString("3",400 - 30, 140 + 3 - 20);
						g.drawString("3",200 - 30, 328 + 3 - 20);
						g.drawString("3",400 - 30, 328 + 3 - 20);
						break;

				case 7 :
						g.drawString("0",200 + 14, 140 + 3 - 26);
						g.drawString("0",400 + 14, 140 + 3 - 26);
						g.drawString("0",200 + 14, 328 + 3 - 26);
						g.drawString("0",400 + 14, 328 + 3 - 26);
						g.drawString("7",200 - 18, 140 + 3 - 26);
						g.drawString("7",400 - 18, 140 + 3 - 26);
						g.drawString("7",200 - 18, 328 + 3 - 26);
						g.drawString("7",400 - 18, 328 + 3 - 26);

						g.drawString("1",200 + 28, 140 + 3 - 11);
						g.drawString("1",400 + 28, 140 + 3 - 11);
						g.drawString("1",200 + 28, 328 + 3 - 11);
						g.drawString("1",400 + 28, 328 + 3 - 11);
						g.drawString("6",200 - 32, 140 + 3 - 11);
						g.drawString("6",400 - 32, 140 + 3 - 11);
						g.drawString("6",200 - 32, 328 + 3 - 11);
						g.drawString("6",400 - 32, 328 + 3 - 11);

						g.drawString("2",200 + 28, 140 + 3 + 11);
						g.drawString("2",400 + 28, 140 + 3 + 11);
						g.drawString("2",200 + 28, 328 + 3 + 11);
						g.drawString("2",400 + 28, 328 + 3 + 11);
						g.drawString("5",200 - 32, 140 + 3 + 11);
						g.drawString("5",400 - 32, 140 + 3 + 11);
						g.drawString("5",200 - 32, 328 + 3 + 11);
						g.drawString("5",400 - 32, 328 + 3 + 11);

						g.drawString("3",200 + 14, 140 + 3 + 29);
						g.drawString("3",400 + 14, 140 + 3 + 29);
						g.drawString("3",200 + 14, 328 + 3 + 29);
						g.drawString("3",400 + 14, 328 + 3 + 29);
						g.drawString("4",200 - 18, 140 + 3 + 29);
						g.drawString("4",400 - 18, 140 + 3 + 29);
						g.drawString("4",200 - 18, 328 + 3 + 29);
						g.drawString("4",400 - 18, 328 + 3 + 29);

						break;
				}
			}
		}




	public void update(Graphics g){
		paint(g);                //do not clear the background every time.
		}

	}


class Packet extends Applet{
	terminal A, B;
	int x;              //top left
	int y;
	public boolean active = false;     //toggle switch;
	public boolean clear = true;     //toggle switch;
	Color seqc, ackc, datac;
	Color old ;
	public int turn ;		//1 -> A, 0 -> B
	int seq, ack , packet_no;
	int oppseq, oppack;
	int seqt, ackt, oppseqt, oppackt;
	int maxseq = 7;
	int initdir = 1;
	int type = 0;
	int lossnoa = 3;
	int lossnob = 3;
	boolean randomloss = false, loss = false;
//	timer tA, tB;
	int counta = 0, countb = 0;			//count
	boolean flaga, flagb;

//	public Packet(int sx, int sy){		 //constructor
	public Packet(int initdir){
		this.initdir = initdir;
		x = 50;
		if (initdir == 1)   //AtoB
			y = 200;
		else y = 269;
		seqc  = Color.green;
		ackc  = Color.pink;
		datac = Color.gray;
		A = new terminal();
		B = new terminal();
		}

	public void settype(int type){
		this.type = type;
		}

	public void setlossno(int lossnoa, int lossnob, boolean randomloss){
		this.lossnoa = lossnoa;
		this.lossnob = lossnob;
		this.randomloss = randomloss;
		}

	public void setinitdir(int initdir){
		this.initdir = initdir;
		turn = initdir;
		}

	public void sendinit(){
		turn = initdir;
		counta = countb = 0;
		flaga = flagb = false;
		if (turn == 1){
			A.transmit();
			seqt = seq = A.getseq();
			ackt = ack = A.getack();
			packet_no = A.getpacketno();
			if (((type == 1 || type == 3) && lossnoa > 1) || type == 0 || type == 2){
				B.receive(seq, ack);
				loss = false;
				}
			else {
				A.decpno();
				loss = true;
				}
			oppseqt = oppseq = maxseq;
			oppackt = oppack = maxseq;
			x = 50;
			y = 200;
			switch (type){
				case 0 : break;
				case 1 : break;
				case 2 : countb = lossnob - 1;break;
				case 3 : countb = lossnob - 1;break;
				default: break;
				}
			}
		else {
			B.transmit();
			oppseqt = seq = B.getseq();
			oppackt = ack = B.getack();
			packet_no = B.getpacketno();
			if (((type == 2 || type == 3) && lossnob > 1) || type == 0 || type == 1){
				A.receive(seq, ack);
				loss = false;
				}
			else {
				B.decpno();
				loss = true;
				}
			seqt = oppseq = maxseq;
			ackt = oppack = maxseq;
			x = 50;
			y = 269;
			switch (type){
				case 0 : break;
				case 1 : counta = lossnoa - 1;break;
				case 2 : break;
				case 3 : counta = lossnoa - 1;break;
				default: break;
				}
			}
		}


	void changeturn(){
		if (turn == 1){    //A to B [(turn = 1) => A, (turn = 0) => B]
			turn = 0;
			if (randomloss && loss){
				loss = false;
				lossnoa = (int)((Math.random() * 100) % 5) + 2;
//				lossnob = (int)((Math.random() * 100) % 3) + 1;
				}
			int t1 = oppseq;   //special case... loss of every 1st packet.
			int t2 = oppack;
			oppseq = seq;
			oppack = ack;
			B.transmit();
			if (type == 0 || ((type == 1 || type == 3) && lossnoa > 1) || type == 2){
				seq = B.getseq();
				ack = B.getack();
				}
			else {
				seq = t1;
				ack = t2;
				}

			packet_no = B.getpacketno();

//			if ((lossnob > 1) && ((type == 0) || (type == 1) || ((type == 2 || type == 3) && countb != (lossnob - 2)))){
			if (type == 0 || type == 1 || ((type == 2 || type == 3) && countb != (lossnob - 2) && lossnob > 1)){
				A.receive(seq, ack);
				loss = false;
				flaga = false;
				}
			else {
				if (type != 3 || (type == 3 && (flaga == false
								|| (initdir == 1 && lossnob == 1)))){
					A.decpno();
					B.decpno();
					}
				loss = true;
				flaga = true;
				}
			seqt = oppseq;
			ackt = oppack;
			oppseqt = seq;
			oppackt = ack;
			countb = (countb + 1) % lossnob;
			}
		else {
			turn = 1;
			if (randomloss && loss){
				loss = false;
//				lossnoa = (int)((Math.random() * 100) % 3) + 1;
				lossnob = (int)((Math.random() * 100) % 5) + 2;
				}
			int t1 = oppseq;
			int t2 = oppack;
			oppseq = seq;
			oppack = ack;
			A.transmit();
			if (type == 0 || ((type == 2 || type == 3) && lossnob > 1) || type == 1){
				seq = A.getseq();
				ack = A.getack();
				}
			else {
				seq = t1;
				ack = t2;
				}
//			if ((type == 0) || (type == 2) || (type == 1 && counta != 1))
			packet_no = A.getpacketno();
 //			if ((lossnoa > 1) && ((type == 0) || (type == 2) || ((type == 1 || type == 3) && counta != (lossnoa - 2)))){
			if (type == 0 || type == 2 || ((type == 1 || type == 3) && counta != (lossnoa - 2) && lossnoa > 1)){
				B.receive(seq, ack);
				loss = false;
				flaga = false;
				}
			else {
				if (type != 3 || (type == 3 && (flaga == false
									|| (initdir == 0 && lossnoa == 1)))){
					B.decpno();
					A.decpno();
					}
				loss = true;
				flaga = true;
				}
			seqt = seq;
			ackt = ack;
			oppseqt = oppseq;
			oppackt = oppack;
			counta = (counta + 1) % lossnoa;
			}
		}


		//The method nextxy() calculates the next position of the frame.

	public int nextxy(int AtoB){
		if (active == false)
			return 0;
		x++;
		if (AtoB == 1)	{		//send packet from A to B
			if (y < 275 - 6){
				y += 2;
				return 1;
				}
			else {
				x += 10;
				if (x > 550 - 45) x = 50;
				return (-1);
				}
			}
		else {
			if (y > 190 + 8){
				y -= 2;
				return 1;
				}
			else {
				x += 10;
				if (x > 550 - 45) x = 50;
				return (-1);
				}
			}
		}

	public int getx(){
		return x;
		}

	public int gety(){
		return y;
		}

	public void setxy(int sx, int sy){
		x = sx;
		y = sy;
		}


	public void sendpacket(Graphics g, int x1, int y1, int erase){

	if (erase == 0){

		switch (maxseq) {
			case 1:
				switch (seqt){
					case 0 : drawCircle(g, 200, 140, 25, 270, 180, false);
						    break;
					case 1 : drawCircle(g, 200, 140, 25, 270, -180, false);
						    break;
					}
				switch (ackt){
					case 0 : drawCircle(g, 400, 140, 25, 270, -180, false);
						    break;
					case 1 : drawCircle(g, 400, 140, 25, 270, 180, false);
						    break;
					}
				switch (oppseqt){
					case 0 : drawCircle(g, 400, 328, 25, 270, 180, false);
						    break;
					case 1 : drawCircle(g, 400, 328, 25, 270, -180, false);
						    break;
					}
				switch (oppackt){
					case 0 : drawCircle(g, 200, 328, 25, 270, -180, false);
						    break;
					case 1 : drawCircle(g, 200, 328, 25, 270, 180, false);
						    break;
					}
					break;

			case 3:
				switch (seqt){
					case 0 : drawCircle(g, 200, 140, 25, 0, 90, false);
						    break;
					case 1 : drawCircle(g, 200, 140, 25, 270, 90, false);
						    break;
					case 2 : drawCircle(g, 200, 140, 25, 270, -90, false);
						    break;
					case 3 : drawCircle(g, 200, 140, 25, 180, -90, false);
						    break;
					}
				switch (ackt){   //frame-expected = ack + 1
					case 0 : drawCircle(g, 400, 140, 25, 270, 90, false);
						    break;
					case 1 : drawCircle(g, 400, 140, 25, 270, -90, false);
						    break;
					case 2 : drawCircle(g, 400, 140, 25, 180, -90, false);
						    break;
					case 3 : drawCircle(g, 400, 140, 25, 0, 90, false);
						    break;
					}
				switch (oppseqt){
					case 0 : drawCircle(g, 400, 328, 25, 0, 90, false);
						    break;
					case 1 : drawCircle(g, 400, 328, 25, 270, 90, false);
						    break;
					case 2 : drawCircle(g, 400, 328, 25, 270, -90, false);
						    break;
					case 3 : drawCircle(g, 400, 328, 25, 180, -90, false);
						    break;
					}
				switch (oppackt){
					case 0 : drawCircle(g, 200, 328, 25, 270, 90, false);
						    break;
					case 1 : drawCircle(g, 200, 328, 25, 270, -90, false);
						    break;
					case 2 : drawCircle(g, 200, 328, 25, 180, -90, false);
						    break;
					case 3 : drawCircle(g, 200, 328, 25, 0, 90, false);
						    break;
					}

				break;
			case 7:
				switch (seqt){
					case 0 : drawCircle(g, 200, 140, 25, 45, 45, false);
						    break;
					case 1 : drawCircle(g, 200, 140, 25, 0, 45, false);
						    break;
					case 2 : drawCircle(g, 200, 140, 25, 315, 45, false);
						    break;
					case 3 : drawCircle(g, 200, 140, 25, 270, 45, false);
						    break;
					case 4 : drawCircle(g, 200, 140, 25, 270, -45, false);
						    break;
					case 5 : drawCircle(g, 200, 140, 25, 225, -45, false);
						    break;
					case 6 : drawCircle(g, 200, 140, 25, 180, -45, false);
						    break;
					case 7 : drawCircle(g, 200, 140, 25, 135, -45, false);
						    break;
					}
				switch (ackt){
					case 0 : drawCircle(g, 400, 140, 25, 0, 45, false);
						    break;
					case 1 : drawCircle(g, 400, 140, 25, 315, 45, false);
						    break;
					case 2 : drawCircle(g, 400, 140, 25, 270, 45, false);
						    break;
					case 3 : drawCircle(g, 400, 140, 25, 270, -45, false);
						    break;
					case 4 : drawCircle(g, 400, 140, 25, 225, -45, false);
						    break;
					case 5 : drawCircle(g, 400, 140, 25, 180, -45, false);
						    break;
					case 6 : drawCircle(g, 400, 140, 25, 135, -45, false);
						    break;
					case 7 : drawCircle(g, 400, 140, 25, 45, 45, false);
						    break;
					}
				switch (oppseqt){
					case 0 : drawCircle(g, 400, 328, 25, 45, 45, false);
						    break;
					case 1 : drawCircle(g, 400, 328, 25, 0, 45, false);
						    break;
					case 2 : drawCircle(g, 400, 328, 25, 315, 45, false);
						    break;
					case 3 : drawCircle(g, 400, 328, 25, 270, 45, false);
						    break;
					case 4 : drawCircle(g, 400, 328, 25, 270, -45, false);
						    break;
					case 5 : drawCircle(g, 400, 328, 25, 225, -45, false);
						    break;
					case 6 : drawCircle(g, 400, 328, 25, 180, -45, false);
						    break;
					case 7 : drawCircle(g, 400, 328, 25, 135, -45, false);
						    break;
					}
				switch (oppackt){
					case 0 : drawCircle(g, 200, 328, 25, 0, 45, false);
						    break;
					case 1 : drawCircle(g, 200, 328, 25, 315, 45, false);
						    break;
					case 2 : drawCircle(g, 200, 328, 25, 270, 45, false);
						    break;
					case 3 : drawCircle(g, 200, 328, 25, 270, -45, false);
						    break;
					case 4 : drawCircle(g, 200, 328, 25, 225, -45, false);
						    break;
					case 5 : drawCircle(g, 200, 328, 25, 180, -45, false);
						    break;
					case 6 : drawCircle(g, 200, 328, 25, 135, -45, false);
						    break;
					case 7 : drawCircle(g, 200, 328, 25, 45, 45, false);
						    break;
					}
				break;
			}  //end of switch ...maxseq
		erase = 1;
		}//erase = 0
		if (active) {
			drawpacket(g, x1, y1);
			active = false;
			}
		else {  //clear
			g.setColor(Color.lightGray);
			g.fillRect(x1 - 2, y1 - 9, 36, 19);
			active = true;
			}
		g.setColor(old);
		}

	public void drawpacket(Graphics g, int x1, int y1){
		if ((type == 1 || type == 3) && lossnoa == 1 && turn == 0 && initdir == 1)
			return;
		if ((type == 2 || type == 3) && lossnob == 1 && turn == 1 && initdir == 0)
			return;
		if (type == 0 ||
		(type == 1 && (turn == 0 || (turn == 1 && (!loss || (y1 < 230 && loss))))) ||
		(type == 2 && (turn == 1 || (turn == 0 && (!loss || (y1 > 230 && loss))))) ||
		(type == 3 && (turn == 0 && (!loss || (y1 > 230 && loss)))
				 || (turn == 1 && (!loss || (y1 < 230 && loss))))){
//		(type == 1 && (turn == 0 || (turn == 1 && (counta != (lossnoa - 1) || (y1 < 230 && counta == (lossnoa - 1)))))) ||
//		(type == 2 && (turn == 1 || (turn == 0 && (countb != (lossnob - 1) || (y1 > 230 && countb == (lossnob - 1)))))) ||
//		(type == 3 && (turn == 0 && (countb != (lossnob - 1) || (y1 > 230 && countb == (lossnob - 1))))
//				 || (turn == 1 && (counta != (lossnoa - 1) || (y1 < 230 && counta == (lossnoa - 1)))))){
			g.setColor(seqc);
			g.fill3DRect(x1, y1, 6, 7, true);
			g.setColor(ackc);
			g.fill3DRect(x1 + 6, y1, 6, 7, true);
			g.setColor(datac);
			g.fill3DRect(x1 + 12, y1, 16, 7, true);
			g.setColor(Color.black);
			g.drawString(String.valueOf(seq), getx() + 1,gety() - 1);
			g.drawString(String.valueOf(ack), getx() + 7,gety() - 1);
			if (turn == 1)
				g.drawString("A" + String.valueOf(packet_no), getx() + 15,gety() - 1);
			else
				g.drawString("B" + String.valueOf(packet_no), getx() + 15,gety() - 1);
			}
		}

	public void drawCircle(Graphics g, int cx, int cy, int radius,
	int sangle, int degrees, boolean clear){
		int x1 = cx - radius;
		int y1 = cy - radius;
		int width = 2 * radius;
		int height = width;
		Color old = g.getColor();

		if (clear){
			g.setColor(Color.lightGray);
			g.fillArc(x1 , y1 , width, height, sangle, degrees);
			g.setColor(old);

			g.drawOval(x1, y1, width, height);
			g.drawLine(cx, y1 + 3, cx, y1 - 3);
			g.drawLine(cx, y1 + height + 3, cx, y1 + height - 3);
			return;
			}
		g.setColor(Color.black);
		g.drawOval(x1, y1, width, height);
		g.drawLine(cx, y1 + 3, cx, y1 - 3);
		g.drawLine(cx, y1 + height + 3, cx, y1 + height - 3);

		if (degrees == 0)
			return;
		g.setColor(Color.red);
		g.fillArc(x1, y1, width, height, sangle, degrees);
		g.setColor(Color.black);
		g.drawOval(x1, y1, width, height);
		g.drawLine(cx, y1 + 3, cx, y1 - 3);
		g.drawLine(cx, y1 + height + 3, cx, y1 + height - 3);

		g.setColor(old);
		return;
		}


	public void setmaxseq(int maxseq){
		this.maxseq = maxseq;
		A.setmaxseq(maxseq);
		B.setmaxseq(maxseq);
		}
	}


class terminal{
	int maxseq = 7;	       //sequence no...1/2/3 bit.
	int next_to_send; 		  //0 or 1
	int frame_expected;        //0 or 1
	int seq;
	int ack;
	int packet_no;

	terminal(){
		next_to_send = 0;
		frame_expected = 0;
		seq = next_to_send;
		ack = maxseq - frame_expected;
		packet_no = -1;
		}

	public void reset(){
		next_to_send = 0;
		frame_expected = 0;
		seq = next_to_send;
		ack = maxseq - frame_expected;
		packet_no = -1;
		return;
		}

	void receive(int rseq, int rack){
		if (rseq == frame_expected){
			if (frame_expected == maxseq) frame_expected = 0;
				else frame_expected++;
			}

		if (rack == next_to_send){
			if (next_to_send == maxseq) next_to_send = 0;
				else next_to_send++;
			}
		}

	void transmit(){
		seq = next_to_send;
		ack = frame_expected - 1;
		if (ack < 0) ack = maxseq;
		packet_no++;
		}

	public int getpacketno(boolean increment){
/*		int pno = packet_no;
		if (increment) packet_no++;
		return pno;*/
		if (increment) packet_no++;
		return packet_no;
		}

	public int getpacketno(){
		return packet_no;
		}

	public void decpno(){
		packet_no--;
		}

	public int getseq(){
		return seq;
		}

	public int getack(){
		return ack;
		}

	public int getmaxseq(){
		return maxseq;
		}

	public void setmaxseq(int maxseq){
		this.maxseq = maxseq;
		}

	}


class menu extends Frame implements ItemListener, TextListener{
	Menu menu1, menu2, menu3, menu4;
	MenuBar menubar1;
	MenuItem menuitem11, menuitem12, menuitem13;
	MenuItem menuitem21, menuitem22, menuitem23;
	MenuItem menuitem31, menuitem32;
	MenuItem menuitem41, menuitem42, menuitem43;
	Choice choice1, choice2;
	Label f1, f2, f3, f4, f41, f5, f6, f7, f8, f9, f10;
	cbpanel panel;
	TextField Delay, Lossatxt, Lossbtxt;
	Checkbox random;
	String s1 = "st", s2 = "nd", s3 = "rd", s4 = "th", s = "  ";


	int delay = 5;
	int maxseq = 7;
	int initdir = 1;  //initdir = 1 => A goes first.
	int type = 0;		//ideal
	int lossnoa = 3;
	int lossnob = 3;
	boolean randomloss = false;

	menu(String title){
		super(title);
//		setBackground(Color.lightGray);


		choice1 = new Choice();
		choice1.add("1 - bit (0 - 1)");
		choice1.add("2 - bit (0 - 3)");
		choice1.add("3 - bit (0 - 7)");
		choice1.select(2);
		choice1.addItemListener(this);

		choice2 = new Choice();
		choice2.add("Ideal (No losses)");
		choice2.add("Loss from A to B");
		choice2.add("Loss from B to A");
		choice2.add("Loss both ways");
		choice2.addItemListener(this);

		panel = new cbpanel();
		panel.cb1.addItemListener(this);
		panel.cb2.addItemListener(this);

		Delay = new TextField(5);
		Delay.addTextListener(this);
		Delay.setText("4");

		Lossatxt = new TextField(2);
		Lossatxt.addTextListener(this);
		Lossatxt.setEnabled(false);
		Lossbtxt = new TextField(2);
		Lossbtxt.addTextListener(this);
		Lossbtxt.setEnabled(false);
		Lossatxt.setText("");
		Lossbtxt.setText("");

		random = new Checkbox("Random Losses", true);
		random.addItemListener(this);
		random.setState(false);
		random.setEnabled(false);

		f1 = new Label("Click 'Done' to save changes, 'X' to cancel", Label.LEFT);
		f2 = new Label("Sequence number : ", Label.LEFT);
		f3 = new Label("Who transmits first ?", Label.LEFT);
		f4 = new Label("One Way Delay (mS)", Label.LEFT);
		f5 = new Label("Type of Simulation", Label.LEFT);
		f7 = new Label("Loss of every", Label.LEFT);
		f8 = new Label(s + "   frame from A", Label.LEFT);
		f9 = new Label("Loss of every", Label.LEFT);
		f10 = new Label(s + "   frame from B", Label.LEFT);

		GridBagLayout gb = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		setLayout(gb);

		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.gridheight = 1;
		gbc.gridwidth = 1;
		gbc.fill = GridBagConstraints.HORIZONTAL;

		add(f2, gbc);
		gbc.gridx = 1;
		f6 = new Label("");
		add(f6, gbc);
		gbc.gridx = 2;
		add(choice1, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		f6 = new Label("");
		add(f6, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		add(f3, gbc);
		gbc.gridx = 1;
		f6 = new Label("");
		add(f6, gbc);
		gbc.gridx = 2;
		add(panel, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		f6 = new Label("");
		add(f6, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		add(f4, gbc);
		gbc.gridx = 1;
		f6 = new Label("");
		add(f6, gbc);
		gbc.gridx = 2;
		add(Delay, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		f6 = new Label("");
		add(f6, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		add(f5, gbc);
		gbc.gridx = 1;
		f6 = new Label("");
		add(f6, gbc);
		gbc.gridx = 2;
		add(choice2, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		f6 = new Label("");
		add(f6, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		add(f7, gbc);
		gbc.gridx = 1;
		f6 = new Label("");
		add(f6, gbc);
		gbc.gridx = 2;
		add(Lossatxt, gbc);
		gbc.gridx = 3;
		add(f8, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		f6 = new Label("");
		add(f6, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		add(f9, gbc);
		gbc.gridx = 1;
		f6 = new Label("");
		add(f6, gbc);
		gbc.gridx = 2;
		add(Lossbtxt, gbc);
		gbc.gridx = 3;
		add(f10, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		f6 = new Label("");
		add(f6, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		f6 = new Label("");
		add(f6, gbc);
		gbc.gridx = 1;
		f6 = new Label("");
		add(f6, gbc);
		gbc.gridx = 2;
		add(random, gbc);

		gbc.gridy++;
		gbc.gridx = 0;
		f6 = new Label("");
		add(f6, gbc);

/*		gbc.gridy++;
		gbc.gridx = 0;
		f6 = new Label("");
		add(f6, gbc);
		gbc.gridx = 1;
		add(f1, gbc);
  */		}


	public void textValueChanged(TextEvent event){
		if (event.getSource() == Delay){
			String temp = Delay.getText();

			float val;
			try {
				val = new Float(temp).floatValue();
				}
			catch(NumberFormatException e){
				val = 4;
				Delay.setText("4");
				}

			if (val < 0.5 || val > 20000) {
				val = 4;
				Delay.setText("4");
				}
			delay = 3 + (int) val / 2;
			}
		if (event.getSource() == Lossatxt){
			String temp = Lossatxt.getText();

			if (!Lossatxt.isEnabled()) return;
			try{
				lossnoa = Integer.parseInt(temp);
				}
			catch(NumberFormatException e){
				lossnoa = 3;
				Lossatxt.setText("3");
				}
			if (lossnoa < 1 || lossnoa > 999){
				lossnoa = 3;
				Lossatxt.setText("3");
				}
			switch (lossnoa % 10){
				case 0 : s = s4; break;
				case 1 : s = s1; break;
				case 2 : s = s2; break;
				case 3 : s = s3; break;
				default: s = s4; break;
				}
			f8.setText(s + "   frame from A");
			}
		if (event.getSource() == Lossbtxt){
			String temp = Lossbtxt.getText();

			if (!Lossbtxt.isEnabled()) return;
			try{
				lossnob = Integer.parseInt(temp);
				}
			catch(NumberFormatException e){
				lossnob = 3;
				Lossbtxt.setText("3");
				}
			if (lossnob < 1 || lossnob > 999){
				lossnob = 3;
				Lossbtxt.setText("3");
				}
			switch (lossnob % 10){
				case 0 : s = s4; break;
				case 1 : s = s1; break;
				case 2 : s = s2; break;
				case 3 : s = s3; break;
				default: s = s4; break;
				}
			f10.setText(s + "   frame from B");
			}
		}

	public void itemStateChanged(ItemEvent event){
		if (event.getItemSelectable() == choice1){
			if (((Choice)event.getItemSelectable()).getSelectedItem() .equals("1 - bit (0 - 1)")){
				maxseq = 1;
				}
			if (((Choice)event.getItemSelectable()).getSelectedItem() .equals("2 - bit (0 - 3)")){
				maxseq = 3;
				}
			if (((Choice)event.getItemSelectable()).getSelectedItem() .equals("3 - bit (0 - 7)")){
				maxseq = 7;
				}
			}
		if (event.getItemSelectable() == choice2){
			if (((Choice)event.getItemSelectable()).getSelectedItem() .equals("Ideal (No losses)")){
				type = 0;
				random.setState(false);
				random.setEnabled(false);
				randomloss = false;
				if (Lossatxt.isEnabled()) Lossatxt.setEnabled(false);
				Lossatxt.setText(" ");
				f8.setText("     frame from A");
				if (Lossbtxt.isEnabled()) Lossbtxt.setEnabled(false);
				Lossbtxt.setText(" ");
				f10.setText("     frame from B");
				}
			if (((Choice)event.getItemSelectable()).getSelectedItem() .equals("Loss from A to B")){
				type = 1;
				if (Lossbtxt.isEnabled()) Lossbtxt.setEnabled(false);
				Lossbtxt.setText(" ");
				f10.setText("     frame from B");
				random.setEnabled(true);
				if (random.getState() == true) return;
				if (Lossatxt.isEnabled()) return;
				Lossatxt.setEnabled(true);
				Lossatxt.setText("3");
				}
			if (((Choice)event.getItemSelectable()).getSelectedItem() .equals("Loss from B to A")){
				type = 2;
				if (Lossatxt.isEnabled()) Lossatxt.setEnabled(false);
				Lossatxt.setText(" ");
				f8.setText("     frame from A");
				random.setEnabled(true);
				if (random.getState() == true) return;
				if (Lossbtxt.isEnabled()) return;
				Lossbtxt.setEnabled(true);
				Lossbtxt.setText("3");
				}
			if (((Choice)event.getItemSelectable()).getSelectedItem() .equals("Loss both ways")){
				type = 3;
				random.setEnabled(true);
				if (random.getState() == true) return;
				if (!Lossatxt.isEnabled()){
					Lossatxt.setEnabled(true);
					Lossatxt.setText("3");
					}
				if (!Lossbtxt.isEnabled()){
					Lossbtxt.setEnabled(true);
					Lossbtxt.setText("3");
					}
				}
			}
		if (event.getItemSelectable() == panel.cb1){
			initdir = 1;
			}
		if (event.getItemSelectable() == panel.cb2){
			initdir = 0;
			}
		if (event.getItemSelectable() == random){
			randomloss = true;
			if (random.getState() == true){
				if (Lossatxt.isEnabled()) Lossatxt.setEnabled(false);
				Lossatxt.setText(" ");
				if (Lossbtxt.isEnabled()) Lossbtxt.setEnabled(false);
				Lossbtxt.setText(" ");
				lossnoa = ((int)(Math.random() * 100) % 4) + 2;
				lossnob = ((int)(Math.random() * 100) % 4) + 2;
				}
			if (random.getState() == false){
				randomloss = false;
				switch (type){
					case 1 :
						if (Lossbtxt.isEnabled()) Lossbtxt.setEnabled(false);
						Lossbtxt.setText(" ");
						if (Lossatxt.isEnabled()) return;
						Lossatxt.setEnabled(true);
						Lossatxt.setText("3");
						break;
					case 2 :
						if (Lossatxt.isEnabled()) Lossatxt.setEnabled(false);
						Lossatxt.setText(" ");
						if (Lossbtxt.isEnabled()) return;
						Lossbtxt.setEnabled(true);
						Lossbtxt.setText("3");
						break;
					case 3 :
						Lossatxt.setEnabled(true);
						Lossatxt.setText("3");
						Lossbtxt.setEnabled(true);
						Lossbtxt.setText("3");
						break;
					default:
						break;
					}
				}
			}
		}

	public int getdelay(){
		return delay;
		}

	public int getmaxseq(){
		return maxseq;
		}

	public int getinitdir(){
		return initdir;
		}

	public int gettype(){
		return type;
		}

	public int getlossnoa(){
		return lossnoa;
		}

	public int getlossnob(){
		return lossnob;
		}

	public boolean israndom(){
		return randomloss;
		}
	}


class cbpanel extends Panel{
	CheckboxGroup cbg;
	Checkbox cb1, cb2;

	cbpanel(){
		cbg = new CheckboxGroup();

		add(cb1 = new Checkbox("A", true, cbg));
		add(cb2 = new Checkbox("B", false, cbg));
		}
	}

class Help extends Frame{    // window for displaying the help.

	ScrollPane scrollpane = new ScrollPane(ScrollPane.SCROLLBARS_AS_NEEDED);
	String str = "\nIntroduction\n"
	             + "=========\n\n" 
					     + "This applet simulates the sliding window protocol. It works for the 1-bit, 2-bit and 3-bit protocols.\n"
					     + "By default the 3-bit protocol is used for the ideal case. The simulation can also be run for cases\n"
						+ "where frame losses occur. \n\n\n"
					     + "Changing the Settings\n"
	             + "==================\n\n" 
					     + "Changing the settings for the simulation is quite straightforward. Click on the 'Change Settings'\n"
					     + "button. The caption changes to 'Done' and a window comes up which offers you a number of options.\n"
					     + "There are textboxes in which you can type in the values and there are also drop-down lists from\n"
					     + "which you can select the desired option just by clicking on it. The options related to losses are\n"
					     + "available only when a loss option is selected from the 'Type of Simulation' field. When you have\n"
					     + "finished with the settings, you can exit by clicking on the 'Done' button whose caption now reverts\n"
							 + "to the original and the options window closes.\n\n\n"	 
					     + "Managing the Simulation\n"
	             + "====================\n\n" 
					     + "To start the simulation, click on the 'Start' button. This causes the 'Stop' and 'Pause' buttons to\n"
					     + "get enabled. As the name suggests, the 'Stop' button, when clicked, stops the simulation and\n"
					     + "restores the screen to the state it was in before the simulation started. The simulation can be\n"
					     + "restarted in the same way as before and the settings can be changed if required. Clicking on the\n"
					     + "'Pause' button during the simulation freezes the simulation. It can be resumed by clicking on the\n"
							 + "'Resume' button.";	
	TextArea text = new TextArea(str, 30, 77, TextArea.SCROLLBARS_NONE);

	Help(String title){
		super(title);
		setLayout(new BorderLayout());
		enableEvents(AWTEvent.WINDOW_EVENT_MASK);
		scrollpane = new ScrollPane();
		add("Center", scrollpane);
		scrollpane.add(text);
		text.setEnabled(false);
		}

  public void processWindowEvent(WindowEvent event){
	if (event.getID() == WindowEvent.WINDOW_CLOSING)
		setVisible(false);
		}
	}