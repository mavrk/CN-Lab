




import java.net.*;
import java.io.*;


class DistVector
{
  public static int aPort = 1200;
  public static int bPort = 1300;
  public static int cPort = 1400;
  public static int dPort = 1500;
  public static int rPort = 1600;
  public static int buffer_size = 1024;
  public static DatagramSocket ds;
  public static byte buffer[] = new byte[buffer_size];
  public static char temp;
  public static int table[][] = new int[4][4];
  public static int sender;
  public static int receiver;
  public static int pos = 6;
  public static int done = 1;    // done... 1 -> Send
                                 //         0 -> Receive


 /*

  Function init() initializes the Routing Table with default values for the
  LPD's between the links, as specified in the figure (given in the HELP file).

 */

  public static void init() throws Exception
  {
    done = 1;
    table[0][0] = 99;
    table[1][1] = 99;
    table[2][2] = 99;
    table[3][3] = 99;
    table[0][1] = 10; table[0][2] = 5; table[0][3] = 40;
    table[1][0] = 10; table[1][3] = 20; table[1][2] = 99;
    table[2][1] = 99; table[2][0] = 5; table[2][3] = 30;
    table[3][1] = 20; table[3][2] = 30; table[3][0] = 40;
  } 




 /*

  Function MappingInteger() maps the nodes (specified as characters) onto
  their corresponding node numbers.

 */
 
  public static int MappingInteger(char temp1) throws Exception
  {
    int res = 0;
    if((temp1 == 'a') || (temp1 == 'A'))
      res = 0;
    if((temp1 == 'b') || (temp1 == 'B'))
      res = 1;
    if((temp1 == 'c') || (temp1 == 'C'))
      res = 2;
    if((temp1 == 'd') || (temp1 == 'D'))
      res = 3;
    return res;
  }




 /*

  Function MappingChar() maps the node numbers (specified as integers) onto
  their corresponding nodes (characters).

 */

  public static char MappingChar(byte temp1) throws Exception
  {
    char res = 'a';

    if(temp1 == 0)
      res = 'a';
    if(temp1 == 1)
      res = 'b';
    if(temp1 == 2)
      res = 'c';
    if(temp1 == 3)
      res = 'd';
    return res;
  }




 /*

  Function ShortestPath() calculates the shortest path between the sender and
  the receiver using the DISTANCE VECTOR ALGORITHM. It also helps in determining
  the intermediate stations along the shortest path.

 */

  public static int ShortestPath() throws Exception
  {
    int i,j,k,x,y,z,f,min = 99;
    int A[][] = new int[4][2];
    int B[][] = new int[4][3];
    int C[][] = new int[4][4];
    int fin[][] = new int[20][4];
    int total[] = new int[20];
    x=0; z=0;
    y=0; f=0;


    for(i = 0;i < 4;i++)
    {
      if(table[sender][i] != 99)
      {
        if(i != receiver)
        { 
          A[x][0] = table[sender][i];
          A[x][1] = i;
          x++;
        }
        else
        { 
          fin[f][0] = table[sender][i];
          fin[f][1] = i;
          total[f] = 1;
          f++;
        }
      }
    }

    
    for(i = 0;i < x;i++)
    {
     for(k = 0;k < 4;k++)
     if(table[A[i][1]][k] != 99)
     {
      if(k != sender)
      {
       if(k != receiver)
       {       
        B[y][0] = (int) (table[A[i][1]][k] + A[i][0]);
        B[y][1] = (int) A[i][1];
        B[y][2] = k;
        y++;
       }

       else
       {           
        fin[f][0] = table[A[i][1]][k] + A[i][0];
        fin[f][1] = A[i][1];
        fin[f][2] = k;
        total[f] = 2;
        f++;
       }
      }
     }
    }


    for(i = 0;i < y;i++)
    {
      for(k = 0;k < 4;k++)
       if(table[B[i][2]][k] != 99)
       {
         if(k != B[i][1])
         {
          if(k == receiver)
          {
           fin[f][0] = table[B[i][2]][k] + B[i][0];
           fin[f][1] = B[i][1];
           fin[f][2] = B[i][2];
           fin[f][3] = k;
           total[f] = 3;
           f++;
          }
         }
       }
    }  // End of third for...

   if(f > 0)
   {
    for(i=0;i < f;i++)
      if(min > fin[i][0])
      {
        min = fin[i][0];
        for(j=0;j < total[i];j++)
          buffer[j+1] =(byte) fin[i][j+1];
      }

    System.out.println("\n\nShortest path to the destination takes " + min + " ns.\n");

    for(j=0;j<3;j++)
    {
      System.out.println("Hop " + (j+1) + " :   STATION - " + (char) MappingChar(buffer[j+1]));
      if(buffer[j+1] == (byte) receiver)
        break;
    }
   }
    return f;
  }  // End of ShortestPath()...





 /*

  Function RoutingTable() maintains the Routing Table Update Session 

 */

  public static void RoutingTable() throws Exception
  {
   while(true)
   {
    int delay = 99;
    DataInputStream inData = new DataInputStream(System.in); 
    System.out.println("\nDo you want to make changes ?");
    System.out.print("Choice :-  ");
    char choice = (char) System.in.read();
    temp = (char) System.in.read();  // for a '\n' character... 
    temp = (char) System.in.read();  // for a '\r' character...

    if((choice == 'y') || (choice == 'Y'))
    {
        System.out.print("\nSource : ");
        char s = (char) System.in.read();
        temp = (char) System.in.read();  // for a '\n' character... 
        temp = (char) System.in.read();  // for a '\r' character...

        int source = (int) MappingInteger(s);

        System.out.print("\nDestination : ");
        char d = (char) System.in.read();
        temp = (char) System.in.read();  // for a '\n' character... 
        temp = (char) System.in.read();  // for a '\r' character...

        int destin = (int) MappingInteger(d);

        System.out.println("\nDo you want to delete the link (Y/N) ?");
        System.out.print("Ans :  ");
        char a = (char) System.in.read();
        temp = (char) System.in.read();  // for a '\n' character... 
        temp = (char) System.in.read();  // for a '\r' character...

        if((a == 'y') || (a == 'Y'))
        {
          delay = 99;
          System.out.println("\nLink between '" + s + "' and '" + d + "' has been deleted...");
        }
        else
        {
          System.out.print("\nLink Propagation Delay(ns) :  ");
          String str = inData.readLine();

          delay = Integer.parseInt(str);
          try
          {
            Thread.sleep(50);
          } catch(InterruptedException e) {}
          System.out.println("\nChanges done !!");
        }
        table[source][destin] = delay;
        table[destin][source] = delay;
        buffer[0] = 33;
        buffer[1] = (byte) source;
        buffer[2] = (byte) destin;
        buffer[3] = (byte) delay;
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),aPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),bPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),cPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),dPort));

    } // End of if...
   }  // End of While...
  }                                      






 /*

  Function TerminalA() maintains the DOS session representing STATION - A.
  It displays appropriate messages when in the SEND / RECEIVE mode.

 */

  public static void TerminalA() throws Exception
  {
   int i,NextDest = 0,count = 0,count1 = 0,rec_present,send_present;

   while(true)
   {
    sender = 0;   // Sender is Terminal A...
      
    if(done == 1)
    {
      count = 0;
      count1 = 0;
      System.out.println("\nSEND mode ...");
      System.out.println("\n\nHit the 'ESC' key to switch to RECEIVE mode.");
      System.out.print("Press 'c' to continue...");
      char t = (char) System.in.read();
      temp = (char) System.in.read();  // for a '\n' character...
      temp = (char) System.in.read();  // for a '\r' character...
      if(t == 27)
      {
        done = 0;
        continue;
      }
      else
      {
        for(i=0;i < 4;i++)
        {
         if(table[sender][i] == 99)
          count1++;
        }
        if(count1 >= 4)
        {
         send_present = 0;
         System.out.println("\nAll links to/from this station have been deleted.");
         System.out.println("Thus, Station A cannot transmit...");
        }
        else
          send_present = 1;

        if(send_present == 0)
        {
          done = 1;
          continue;
        }

       do
       {
        count = 0;
        System.out.println("\nEnter the station to which data byte is to be transmitted...");
        System.out.print("\nReceiving Station : ");
        char st = (char) System.in.read();
        temp = (char) System.in.read();  // for a '\n' character...
        temp = (char) System.in.read();  // for a '\r' character...


        if((st == 'd') || (st == 'D'))
         receiver = 3;
        else
         if((st == 'b') || (st == 'B'))
          receiver = 1;
         else
          if((st == 'c') || (st == 'C'))
           receiver = 2;
          else
            receiver = 0;

        if(receiver != 0)
        {
          int  path = ShortestPath();

          if(path == 0)
          {
           rec_present = 0;
           System.out.println("\nSORRY !! ...  There exists no path to STATION - " + st);
           System.out.println("\nPlease specify another destination...");
          }
          else
           rec_present = 1;         
        }
        else
        {
          rec_present = 0;
          System.out.println("\nInvalid destination specified...Try again");
        }

       } while(rec_present == 0); 

       System.out.print("\n\nEnter the data byte (0-9) to be transmitted :- ");
       byte datum = (byte) System.in.read();
       temp = (char) System.in.read();  // for a '\n' character... 
       temp = (char) System.in.read();  // for a '\r' character...

       buffer[0] = datum;

       if(buffer[1] == 1)
        NextDest = bPort;
       else
        if(buffer[1] == 2)
          NextDest = cPort;
        else
          if(buffer[1] == 3)
            NextDest = dPort;

       buffer[4] = (byte) receiver;
       buffer[5] = (byte) sender;

       ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),NextDest));
       done = 0;
       continue;
      }
    }

    else  
    {
     System.out.println("\nRECEIVE mode ...");
     DatagramPacket a = new DatagramPacket(buffer,buffer.length);
     ds.receive(a);
     if(buffer[0] == 88)
     {
       done = 1;
       continue;
     }
     else
     {
	if(buffer[0] == 33)
      	{
	System.out.print("\nRouting Table Updation in progress ... ");
        try
        {
          Thread.sleep(1000);
        } catch(InterruptedException e) {}
        System.out.println(" Done !!\n");
        int send = (int) buffer[1];
        int rec  = (int) buffer[2];
        int del  = (int) buffer[3];
        table[send][rec] = del;
        table[rec][send] = del;
        done = 1;
        continue;
      }
      else
      {
       if(buffer[4] == 0)
       {
        System.out.println("\nDestination Reached !!!");
        buffer[0] -= 48;
        System.out.println("\nThe data byte received is : " + buffer[0]);
        done = 1;  // Implies any station can now send...
        buffer[0] = 88; // buffer[0] = 88 implies that transmission activity is over...
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),bPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),cPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),dPort));
        continue;
       }
       else
       {
        if(buffer[1] == 0)
        {
         System.out.println("\nReceived the data packet from STATION - " + (char) MappingChar(buffer[5])); 
         System.out.println("\nPassing on the data packet to STATION - " + (char) MappingChar(buffer[2])); 
         if(buffer[2] == 1)
           NextDest = bPort;
         else
           if(buffer[2] == 2)
             NextDest = cPort;
           else
             if(buffer[2] == 3)
               NextDest = dPort;
        }
        else
        {
         System.out.println("\nReceived the data packet from NODE - " + (char) MappingChar(buffer[1])); 
         System.out.println("\nPassing on the data packet to NODE - " + (char) MappingChar(buffer[4])); 
         if(buffer[2] == 0)
         {
          if(buffer[4] == 1)
            NextDest = bPort;
          else
            if(buffer[4] == 2)
              NextDest = cPort;
            else
              if(buffer[4] == 3)
                NextDest = dPort;
         }
        }

        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),NextDest));
       }  // End of If-Else...
      }   // End of If-Else buffer[0] = 33 ...
     }    // End of If-Else buffer[0] = 88 ...
    }     // End of If-Else(done == 1)
   }      // End of While...
  }




 /*

  Function TerminalB() maintains the DOS session representing STATION - B.
  It displays appropriate messages when in the SEND / RECEIVE mode.

 */

  public static void TerminalB() throws Exception
  {
   int i,NextDest = 0,count = 0,count1 = 0,rec_present,send_present;

   while (true)
   {
    sender = 1;   // Sender is Terminal B...

    if(done == 1)
    {
      count = 0;
      count1 = 0;
      System.out.println("\nSEND mode ...");
      System.out.println("\n\nHit the 'ESC' key to switch to RECEIVE mode.");
      System.out.print("Press 'c' to continue...");
      char t = (char) System.in.read();
      temp = (char) System.in.read();  // for a '\n' character...
      temp = (char) System.in.read();  // for a '\r' character...
      if(t == 27)
      {
        done = 0;
        continue;
      }
      else
      {
        for(i=0;i < 4;i++)
        {
         if(table[sender][i] == 99)
          count1++;
        }
        if(count1 >= 4)
        {
         send_present = 0;
         System.out.println("\nAll links to/from this station have been deleted.");
         System.out.println("Thus, Station B cannot transmit...");
        }
        else
          send_present = 1;

        if(send_present == 0)
        {
          done = 1;
          continue;
        }

       do
       {
        count = 0;
        System.out.println("\nEnter the station to which data byte is to be transmitted...");
        System.out.print("\nReceiving Station : ");
        char st = (char) System.in.read();
        temp = (char) System.in.read();  // for a '\n' character... 
        temp = (char) System.in.read();  // for a '\r' character...


        if((st == 'd') || (st == 'D'))
         receiver = 3;
        else
         if((st == 'a') || (st == 'A'))
          receiver = 0;
         else
          if((st == 'c') || (st == 'C'))
           receiver = 2;
          else
            receiver = 1;

        if(receiver != 1)
        {
          int  path = ShortestPath();

          if(path == 0)
          {
           rec_present = 0;
           System.out.println("\nSORRY !! ...  There exists no path to STATION - " + st);
           System.out.println("\nPlease specify another destination...");
          }
          else
           rec_present = 1;         
        }
        else
        {
          rec_present = 0;
          System.out.println("\nInvalid destination specified...Try again");
        }

       } while(rec_present == 0);

       System.out.print("\n\nEnter the data byte (0-9) to be transmitted :- ");
       byte datum = (byte) System.in.read();
       temp = (char) System.in.read();  // for a '\n' character... 
       temp = (char) System.in.read();  // for a '\r' character...

       buffer[0] = datum;

       if(buffer[1] == 0)
        NextDest = aPort;
       else
        if(buffer[1] == 2)
          NextDest = cPort;
        else
          if(buffer[1] == 3)
            NextDest = dPort;

       buffer[4] = (byte) receiver;
       buffer[5] = (byte) sender;

       ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),NextDest));
       done = 0;
       continue;
      }
    }

    else 
    {
     System.out.println("\nRECEIVE mode...");
     DatagramPacket b = new DatagramPacket(buffer,buffer.length);
     ds.receive(b);
     if(buffer[0] == 88)
     {
       done = 1;
       continue;
     }
     else
     {
      if(buffer[0] == 33)
      {
        System.out.print("\nRouting Table Updation in progress ... ");
        try
        {
          Thread.sleep(1000);
        } catch(InterruptedException e) {}
        System.out.println(" Done !!\n");
        int send = (int) buffer[1];
        int rec  = (int) buffer[2];
        int del  = (int) buffer[3];
        table[send][rec] = del;
        table[rec][send] = del;
        done = 1;
        continue;
      }
      else
      {
       if(buffer[4] == 1)
       {
        System.out.println("\nDestination reached !!!");
        buffer[0] -= 48;
        System.out.println("\nThe data byte received is : " + buffer[0]);
        done = 1;  // Implies any station can now send...
        buffer[0] = 88; // buffer[0] = 88 implies that transmission activity is over...
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),aPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),cPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),dPort));
        continue;
       }
       else
       {
        if(buffer[1] == 1)
        {
          System.out.println("\nReceived the data packet from STATION - " + (char) MappingChar(buffer[5])); 
          System.out.println("\nPassing on the data packet to STATION - " + (char) MappingChar(buffer[2])); 
          if(buffer[2] == 0)
            NextDest = aPort;
          else
            if(buffer[2] == 2)
              NextDest = cPort;
            else
              if(buffer[2] == 3)
                NextDest = dPort;
        }

        else
        {
         if(buffer[2] == 1)
         {
          System.out.println("\nReceived the data packet from STATION - " + (char) MappingChar(buffer[1])); 
          System.out.println("\nPassing on the data packet to STATION - " + (char) MappingChar(buffer[4])); 
          if(buffer[4] == 0)
            NextDest = aPort;
          else
            if(buffer[4] == 2)
              NextDest = cPort;
            else
              if(buffer[4] == 3)
                NextDest = dPort;
         }
        }

        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),NextDest));
       }  // End of If-Else ...
      }   // End of If-Else buffer[0] == 33...
     }    // End of If-Else buffer[0] = 88 ...
    }     // End of If-Else(done == 1)
   }      // End of While...
  }





 /*

  Function TerminalC() maintains the DOS session representing STATION - C.
  It displays appropriate messages when in the SEND / RECEIVE mode.

 */

  public static void TerminalC() throws Exception
  {
   int i,NextDest = 0,count = 0,count1 = 0,rec_present,send_present;

   while (true)
   {
    sender = 2;   // Sender is Terminal C...

    if(done == 1)
    {
      count = 0;
      count1 = 0;
      System.out.println("\nSEND mode ...");
      System.out.println("\n\nHit the 'ESC' key to switch to RECEIVE mode.");
      System.out.print("Press 'c' to continue...");
      char t = (char) System.in.read();
      temp = (char) System.in.read();  // for a '\n' character...
      temp = (char) System.in.read();  // for a '\r' character...
      if(t == 27)
      {
        done = 0;
        continue;
      }
      else
      {
        for(i=0;i < 4;i++)
        {
         if(table[sender][i] == 99)
          count1++;
        }
        if(count1 >= 4)
        {
         send_present = 0;
         System.out.println("\nAll links to/from this station have been deleted.");
         System.out.println("Thus, Station C cannot transmit...");
        }
        else
          send_present = 1;

        if(send_present == 0)
        {
          done = 1;
          continue;
        }

       do
       {
        count = 0;
        System.out.println("\nEnter the station to which data byte is to be transmitted...");
        System.out.print("\nReceiving Station : ");
        char st = (char) System.in.read();
        temp = (char) System.in.read();  // for a '\n' character... 
        temp = (char) System.in.read();  // for a '\r' character...

        if((st == 'b') || (st == 'B'))
         receiver = 1;
        else
         if((st == 'a') || (st == 'A'))
          receiver = 0;
         else
          if((st == 'd') || (st == 'D'))
           receiver = 3;
          else
            receiver = 2;

        if(receiver != 2)
        {
          int  path = ShortestPath();

          if(path == 0)
          {
           rec_present = 0;
           System.out.println("\nSORRY !! ...  There exists no path to STATION - " + st);
           System.out.println("\nPlease specify another destination...");
          }
          else
           rec_present = 1;         
        }
        else
        {
          rec_present = 0;
          System.out.println("\nInvalid destination specified...Try again");
        }
       
       } while(rec_present == 0);

       System.out.print("\n\nEnter the data byte (0-9) to be transmitted :- ");
       byte datum = (byte) System.in.read();
       temp = (char) System.in.read();  // for a '\n' character... 
       temp = (char) System.in.read();  // for a '\r' character...

       buffer[0] = datum;

       if(buffer[1] == 1)
        NextDest = bPort;
       else
        if(buffer[1] == 0)
          NextDest = aPort;
        else
          if(buffer[1] == 3)
            NextDest = dPort;

       buffer[4] = (byte) receiver;
       buffer[5] = (byte) sender;

       ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),NextDest));
       done = 0;
       continue;
      }
    }

    else
    {
     System.out.println("\nRECEIVE mode...");
     DatagramPacket c = new DatagramPacket(buffer,buffer.length);
     ds.receive(c);
     if(buffer[0] == 88)
     {
       done = 1;
       continue;
     }
     else
     {
      if(buffer[0] == 33)
      {
        System.out.print("\nRouting Table Updation in progress ... ");
        try
        {
          Thread.sleep(1000);
        } catch(InterruptedException e) {}
        System.out.println(" Done !!\n");
        int send = (int) buffer[1];
        int rec  = (int) buffer[2];
        int del  = (int) buffer[3];
        table[send][rec] = del;
        table[rec][send] = del;
        done = 1;
        continue;
      }
      else
      {
       if(buffer[4] == 2)
       {
        System.out.println("\nDestination reached !!!");
        buffer[0] -= 48;
        System.out.println("\nThe data byte received is : " + buffer[0]);
        done = 1;  // Implies any station can now send...
        buffer[0] = 88; // buffer[0] = 88 implies that transmission activity is over...
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),bPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),aPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),dPort));
        continue;
       }
       else
       {
        if(buffer[1] == 2)
        {
          System.out.println("\nReceived the data packet from STATION - " + (char) MappingChar(buffer[5])); 
          System.out.println("\nPassing on the data packet to STATION - " + (char) MappingChar(buffer[2])); 

          if(buffer[2] == 1)
            NextDest = bPort;
          else
            if(buffer[2] == 0)
              NextDest = aPort;
            else
              if(buffer[2] == 3)
                NextDest = dPort;
        }

        else
        {
         if(buffer[2] == 2)
         {
          System.out.println("\nReceived the data packet from STATION - " + (char) MappingChar(buffer[1])); 
          System.out.println("\nPassing on the data packet to STATION - " + (char) MappingChar(buffer[4])); 

          if(buffer[4] == 1)
            NextDest = bPort;
          else
            if(buffer[4] == 0)
              NextDest = aPort;
            else
              if(buffer[4] == 3)
                NextDest = dPort;
         }
        }

        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),NextDest));
       }  // End of If-Else...
      }   // End of If-Else buffer[0] == 33...
     }    // End of If-Else buffer[0] = 88 ...
    }     // End of If-Else(done == 1)
   }      // End of While...
  }





 /*

  Function TerminalD() maintains the DOS session representing STATION - D.
  It displays appropriate messages when in the SEND / RECEIVE mode.

 */

  public static void TerminalD() throws Exception
  {
   int i,NextDest = 0,count = 0,count1 = 0,rec_present,send_present;

   while (true)
   {
    sender = 3;   // Sender is Terminal D...


    if(done == 1)
    {
      count = 0;
      count1 = 0;
      System.out.println("\nSEND mode ...");
      System.out.println("\n\nHit the 'ESC' key to switch to RECEIVE mode.");
      System.out.print("Press 'c' to continue...");
      char t = (char) System.in.read();
      temp = (char) System.in.read();  // for a '\n' character...
      temp = (char) System.in.read();  // for a '\r' character...
      if(t == 27)
      {
        done = 0;
        continue;
      }
      else
      {
        for(i=0;i < 4;i++)
        {
         if(table[sender][i] == 99)
          count1++;
        }
        if(count1 >= 4)
        {
         send_present = 0;
         System.out.println("\nAll links to/from this station have been deleted.");
         System.out.println("Thus, Station D cannot transmit...");
        }
        else
          send_present = 1;

        if(send_present == 0)
        {
          done = 1;
          continue;
        }

       do
       {
        count = 0;
        System.out.println("\nEnter the station to which data byte is to be transmitted...");
        System.out.print("\nReceiving Station : ");
        char st = (char) System.in.read();
        temp = (char) System.in.read();  // for a '\n' character... 
        temp = (char) System.in.read();  // for a '\r' character...

        if((st == 'b') || (st == 'B'))
         receiver = 1;
        else
         if((st == 'a') || (st == 'A'))
          receiver = 0;
         else
          if((st == 'c') || (st == 'C'))
           receiver = 2;
          else
            receiver = 3;

        if(receiver != 3)
        {
          int  path = ShortestPath();

          if(path == 0)
          {
           rec_present = 0;
           System.out.println("\nSORRY !! ...  There exists no path to STATION - " + st);
           System.out.println("\nPlease specify another destination...");
          }
          else
           rec_present = 1;         
        }
        else
        {
          rec_present = 0;
          System.out.println("\nInvalid destination specified...Try again");
        }

       } while(rec_present == 0);

       System.out.print("\n\nEnter the data byte (0-9) to be transmitted :- ");
       byte datum = (byte) System.in.read();
       temp = (char) System.in.read();  // for a '\n' character... 
       temp = (char) System.in.read();  // for a '\r' character...

       buffer[0] = datum;

       if(buffer[1] == 1)
        NextDest = bPort;
       else
        if(buffer[1] == 2)
          NextDest = cPort;
        else
          if(buffer[1] == 0)
            NextDest = aPort;

       buffer[4] = (byte) receiver;
       buffer[5] = (byte) sender;

       ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),NextDest));
       done = 0;
       continue;
      }
    }

    else
    {
     System.out.println("\nRECEIVE mode...");
     DatagramPacket d = new DatagramPacket(buffer,buffer.length);
     ds.receive(d);
     if(buffer[0] == 88)
     {
       done = 1;
       continue;
     }
     else
     {
      if(buffer[0] == 33)
      {
        System.out.print("\nRouting Table Updation in progress ... ");
        try
        {
          Thread.sleep(1000);
        } catch(InterruptedException e) {}
        System.out.println(" Done !!\n");
        int send = (int) buffer[1];
        int rec  = (int) buffer[2];
        int del  = (int) buffer[3];
        table[send][rec] = del;
        table[rec][send] = del;
        done = 1;
        continue;
      }
      else
      {
       if(buffer[4] == 3)
       {
        System.out.println("\nDestination reached !!!");
        buffer[0] -= 48;
        System.out.println("\nThe data byte received is : " + buffer[0]);
        done = 1;  // Implies any station can now send...
        buffer[0] = 88; // buffer[0] = 88 implies that transmission activity is over...
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),bPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),cPort));
        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),aPort));
        continue;
       }
       else
       {
        if(buffer[1] == 3)
        {
          System.out.println("\nReceived the data packet from STATION - " + (char) MappingChar(buffer[5])); 
          System.out.println("\nPassing on the data packet to STATION - " + (char) MappingChar(buffer[2])); 

          if(buffer[2] == 1)
            NextDest = bPort;
          else
            if(buffer[2] == 2)
              NextDest = cPort;
            else
              if(buffer[2] == 0)
                NextDest = aPort;
        }

        else
        {
         if(buffer[2] == 3)
         {
          System.out.println("\nReceived the data packet from STATION - " + (char) MappingChar(buffer[1])); 
          System.out.println("\nPassing on the data packet to STATION - " + (char) MappingChar(buffer[4])); 
          if(buffer[4] == 1)
            NextDest = bPort;
          else
            if(buffer[4] == 2)
              NextDest = cPort;
            else
              if(buffer[4] == 0)
                NextDest = aPort;
         }
        }

        ds.send(new DatagramPacket(buffer,pos,InetAddress.getLocalHost(),NextDest));
       } // End of If-Else...
      }  // End of If-Else buffer[0] == 33...
     }   // End of If-Else buffer[0] = 88 ...
    }    // End of If-Else(done == 1)
   }     // End of While...
  }




 /*

  The main() Function accepts in-line arguments (a/b/c/d/r) from the user
  and starts the DOS session representing the corresponding STATION or the
  Routing Table Update Session.

  */

  public static void main(String args[]) throws Exception
  {

    if(args.length < 1)
      System.out.println("Error !\nUsage : java DistVector [a/b/c/d/r] ");
    else
    {
      init();

      if(args[0].equals("r"))
      {
        ds = new DatagramSocket(rPort);
        System.out.println("\n  Routing Table Update Session");
        System.out.println("--------------------------------");
        RoutingTable();
      }

      if(args[0].equals("a"))
      {
        ds = new DatagramSocket(aPort);
        System.out.println("\n  Station - A");
        System.out.println("----------------");
        TerminalA();
      }

      if(args[0].equals("b"))
      {
        ds = new DatagramSocket(bPort);
        System.out.println("\n  Station - B");
        System.out.println("----------------");
        TerminalB();
      }

      if(args[0].equals("c"))
      {
        ds = new DatagramSocket(cPort);
        System.out.println("\n  Station - C");
        System.out.println("----------------");
        TerminalC();
      }

      if(args[0].equals("d"))
      {
        ds = new DatagramSocket(dPort);
        System.out.println("\n  Station - D");
        System.out.println("----------------");
        TerminalD();
      }

    }    // End of if-else...
  }  // End of Main()...


} // End of Class DistVector()... 
