
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lab7
 */
public class ServerClass {
    
    private static int uniqueId = 0;
    private static int currentQues = 0;
    private ArrayList<ClientThread> clients;
    private int port;
    private boolean keepGoing;
    String ip;
    public ServerClass(int port) {
        this.port = port;
        clients = new ArrayList();
    }
    
    public void start() {
        keepGoing = true;
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            boolean p2 = false;
            while(keepGoing) {
                System.out.println("Waiting for clients on port " + port);
                
                Socket socket = serverSocket.accept();
                System.out.println("Connection accepted");
                if(!keepGoing)
                    break;
                ClientThread t = new ClientThread(socket);
                clients.add(t);
                t.start();
            }
        } catch (Exception e) {
            String msg = "Exception on new ServerSocket: " + e + "\n";
                System.out.println(""+msg);
        }
    }
    
    public static void main(String argv[]) throws Exception {
        ServerClass sc = new ServerClass(1060);
        sc.start();
    }
    
    class ClientThread extends Thread {
        Socket socket;
        ObjectInputStream cInput;
        ObjectOutputStream cOutput;
        
        int connectionId;
        String marker;
        
        ClientThread(Socket socket) {
            connectionId = uniqueId++;
            this.socket = socket;
            try {
                cOutput = new ObjectOutputStream(socket.getOutputStream());
                cInput = new ObjectInputStream(socket.getInputStream());
            } catch (Exception e) {
                System.out.println("Error creating streams");
            }
        }
        
        public void run() {
            while(true) {
                try {
                    Object obj = cInput.readObject();
                    System.out.println(""+obj.toString());
                    sendObject(new String("Hi client " + connectionId + " I read your message but I am busy"));
                } catch (IOException e) {
                    System.out.println("Error reading object from client " + connectionId);
                    close();
                    break;
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(ServerClass.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
        }
        
        private void close() {
            try {
                if(cOutput != null)
                    cOutput.close();
                if(cInput != null)
                    cInput.close();
                if(socket != null)
                    socket.close();
            } catch (Exception e) {
            }
        }
        
        public boolean sendObject(Object obj) {
            try {
                if(!socket.isConnected()) {
                    close();
                    return false;
                }
                System.out.println("Sending object (" + obj.toString() + ")");
                cOutput.writeObject(obj);
            } catch (Exception e) {
                System.out.println("Error sending object to client " + connectionId);
                e.printStackTrace();
            }
            return true;
        }
    }
}
