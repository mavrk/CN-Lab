
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

class ClientClass {

    private ObjectInputStream cInput;
    private ObjectOutputStream cOutput;
    private Socket socket;
    private int port;
    private String serverIp;
    private BufferedReader br;

    public ClientClass(int port, String serverIp) {
        this.port = port;
        this.serverIp = serverIp;
        this.br = new BufferedReader(new InputStreamReader(System.in));
    }

    public boolean startConnection() {
        try {
            socket = new Socket(serverIp, port);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }

        String msg = "Conncetion accepted " + socket.getInetAddress() + " : " + socket.getPort();
        System.out.println("" + msg);

        try {
            cInput = new ObjectInputStream(socket.getInputStream());
            cOutput = new ObjectOutputStream(socket.getOutputStream());
        } catch (IOException eIO) {
            System.out.println("Exception creating new Input/output Streams: " + eIO);
            return false;
        }
     
        new ListenFromServer().start();
     
        
        return true;
    }

    public void sendObject(Object obj) {
        try {
            System.out.println("Sending message " + obj.toString());
            cOutput.writeObject(obj);
        } catch (Exception e) {
            System.out.println("Error sending object " + e);
        }
    }

    class ListenFromServer extends Thread {

        public void run() {
            while (true) {
                try {
                    Object obj = cInput.readObject();
                    System.out.println("Messge rcvd");
                    System.out.println(obj);
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }
    }

    public static void main(String[] args) throws IOException {
        ClientClass cc = new ClientClass(1080, "localhost");
        cc.startConnection();
        while(true){
            String msg = cc.br.readLine();
            cc.sendObject(msg);
        }        
    }

}
