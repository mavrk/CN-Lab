/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package client;
import java.io.*;
import java.net.*;
import java.util.*;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel; 
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset; 
import org.jfree.data.category.DefaultCategoryDataset; 
import org.jfree.ui.ApplicationFrame; 
import org.jfree.ui.RefineryUtilities; 

class client1 {
  Socket s = null;
  DataOutputStream dos = null;

  public client1(int port) throws Exception {
    s = new Socket("localhost", port);
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter your choice");
    int choice = sc.nextInt();
    dos = new DataOutputStream(s.getOutputStream());
    dos.writeUTF(Integer.toString(choice));
    System.out.println("Choice Sent to server");
    //s.close();
  }

}

class Client {
    public static void main(String args[]) throws Exception {
        client1 user = new client1(9999);
    }
}
