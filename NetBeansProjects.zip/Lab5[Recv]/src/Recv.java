
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lab7
 */
public class Recv {
    public static void main(String[] args) throws IOException {
        
        ServerSocket ss = new ServerSocket(1080);
        Socket s = ss.accept();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        DataInputStream in = new DataInputStream(s.getInputStream());
        String str1;
        System.out.println("Enter number of iterations");
        int it = Integer.parseInt(br.readLine());
        int intr = 0;
        int msg[] = new int[8];
        for (int i = 0; i < 8; i++) {
            msg[i] = i;
        }

        PrintStream p;
        int no;
        p = new PrintStream(s.getOutputStream());
        p.println(it);
        System.out.println("Enter window size");
        no = Integer.parseInt(br.readLine());
        p.println(no);
        int i = 0;
        while (intr < it) {
            p.println(msg[i]);
            i++;

            if (i == no) {
                str1 = in.readLine();
                System.out.println(str1);
            }
            if (i == 8) {
                i = 0;
                intr++;
            }
        }
        ss.close();
        s.close();
    }
}
    
