
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author lab7
 */
public class ProxyServer {

    private static int uniqueId = 0;
    private static int currentQues = 0;
    private ArrayList<ClientThread> clients;
    private int port;
    private boolean keepGoing;
    private int serverPort;
    private String serverIp;

    String ip;

    public ProxyServer(int port) {
        this.port = port;
        clients = new ArrayList();
        this.serverIp = "localhost";
        this.serverPort = 1060;
    }

    public void start() {
        keepGoing = true;
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            boolean p2 = false;
            while (keepGoing) {
                System.out.println("[Proxy] Waiting for clients on port " + port);

                Socket socket = serverSocket.accept();
                if (!keepGoing) {
                    break;
                }
                ClientThread t = new ClientThread(socket);
                clients.add(t);
                t.start();
            }
        } catch (Exception e) {
            String msg = "[Proxy] Exception on new ServerSocket: " + e + "\n";
            System.out.println("" + msg);
        }
    }

    public static void main(String argv[]) throws Exception {
        //proxy server started at 1080
        ProxyServer sc = new ProxyServer(1080);
        sc.start();
    }

    class ClientThread extends Thread {

        Socket socket;
        ObjectInputStream cInput;
        ObjectOutputStream cOutput;
        ObjectInputStream sInput;
        ObjectOutputStream sOutput;

        int connectionId;
        String marker;

        ClientThread(Socket socket) throws IOException {
            //connect to server here and create streams
            Socket serverSocket = new Socket(serverIp, serverPort);
            try {
                sInput = new ObjectInputStream(serverSocket.getInputStream());
                sOutput = new ObjectOutputStream(serverSocket.getOutputStream());
            } catch (IOException eIO) {
                System.out.println("Exception creating new Input/output Streams [Proxy to Server]: " + eIO);

            }

            connectionId = uniqueId++;
            System.out.println(""+connectionId);
            this.socket = socket;
            try {
                cOutput = new ObjectOutputStream(socket.getOutputStream());
                cInput = new ObjectInputStream(socket.getInputStream());
            } catch (Exception e) {
                System.out.println("Error creating streams [Proxy]");
            }
            
            new ListenFromServer().start();
        }

        public void run() {
            while (true) {
                //read from client and send to server
                try {
                    Object obj = cInput.readObject();
                    System.out.println(obj);
                    //send obj to server
                    sOutput.writeObject(obj);

                } catch (IOException e) {
                    System.out.println("Error reading object from client [Proxy]" + connectionId);
                    close();
                    break;
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(ProxyServer.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
        }

        //listen from server and send back to client
        class ListenFromServer extends Thread {

            public void run() {
                while (true) {
                    try {
                        Object obj = sInput.readObject();
                        System.out.println(obj);
                        cOutput.writeObject(obj);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        }

        private void close() {
            try {
                if (cOutput != null) {
                    cOutput.close();
                }
                if (cInput != null) {
                    cInput.close();
                }
                if (socket != null) {
                    socket.close();
                }
            } catch (Exception e) {
            }
        }

        public boolean sendObject(Object obj) {
            try {
                if (!socket.isConnected()) {
                    close();
                    return false;
                }
                System.out.println("Sending object [Proxy] " + obj.toString());
                cOutput.writeObject(obj);
            } catch (Exception e) {
                System.out.println("Error sending object to client [Proxy] " + connectionId);
                e.printStackTrace();
            }
            return true;
        }
    }
}
