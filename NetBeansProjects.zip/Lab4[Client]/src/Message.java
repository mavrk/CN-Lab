
import java.io.Serializable;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lab7
 */
public class Message implements Serializable{
    protected static final long serialVersionUID = 2L;
    
    Integer seqNo;
    String message;
    
    public Message(Integer seqNo, String message){
        this.seqNo = seqNo;
        this.message = message;
    }
    
}
