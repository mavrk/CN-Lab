package sliding_window;
import java.net.*;

public class Sliding_window {
    
    public static void main(String[] args) {
       
    }
    
}
