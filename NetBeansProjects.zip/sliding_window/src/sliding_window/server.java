package sliding_window;
import java.net.*;
import java.util.*;
import java.io.*;

public class server {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of elements");
        int n = sc.nextInt();
        System.out.println("Enter the list of data to be sent (space separated)");
        int inp[] = new int[n + 5];
        
        for (int i = 0; i < n; i++) {
            inp[i] = sc.nextInt();
        }
        
        try {
            ServerSocket ss = new ServerSocket(9999);
            System.out.println("Server started at port 9999");
            Socket s = ss.accept();
            System.out.println("Client connected");
            DataInputStream dis = new DataInputStream(new BufferedInputStream(s.getInputStream()));
            DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));
            int resp = Integer.parseInt(dis.readUTF());
            
            if (resp == 1) {
                
            }
            
        } catch(Exception e) {
            System.out.println(e.getMessage());
        }
        
        
        
        
        
    }
}
