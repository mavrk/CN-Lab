package server;
import java.io.*;
import java.awt.*;
import java.net.*;


public class Server extends Frame{
  Socket s = null;
  ServerSocket ss = null;
  DataInputStream dis = null;
  int count = 5;

  public Server(int port) throws Exception {
    ss = new ServerSocket(port);    
    int arr[] = new int[6];

    for (int i = 0; i < 5; i++) {   
      System.out.println("Waiting for client to Connect");
      s = ss.accept();
      System.out.println("Client " + i + " is connected");
      dis = new DataInputStream(new BufferedInputStream(s.getInputStream()));
      int response = Integer.parseInt(dis.readUTF());
      arr[response]++;
      System.out.println("Data fetched from Client " + i);
      //s.close();
    }
      System.out.println("Data fetched from all Clients. Shutting down server.");
      //ss.close();
      int maxm = 0, ans = 0;
      for (int i = 1; i < 6; i++) {
          if (arr[i] > maxm) {
              maxm = arr[i];
              ans = i;
          }
      }

      
      System.out.println("Answer is " + ans);
  }


  public static void main(String args[]) throws IOException {
    try {
        Server vote_machine = new Server(9999);
    }
    catch (Exception e) {
      System.out.println(e.getMessage());
    }


  }
}
