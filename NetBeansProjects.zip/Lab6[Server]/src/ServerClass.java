
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lab7
 */
public class ServerClass {
    
    private static int uniqueId = 0;
    private static int currentQues = 0;
    private ArrayList<ClientThread> clients;
    private int port;
    private boolean keepGoing;
    String ip;
    boolean[] valid = {true,true,true,true,true,true,true,true,true};
    String[] boardState = {"N","N","N","N","N","X","N","N","N"};
    int currentTurn = 0;
    public ServerClass(int port) {
        this.port = port;
        clients = new ArrayList();
    }
    
    public void start() {
        keepGoing = true;
        try {
            ServerSocket serverSocket = new ServerSocket(port);
            boolean p2 = false;
            while(keepGoing) {
                System.out.println("Waiting for clients on port " + port);
                
                Socket socket = serverSocket.accept();
                
                if(!keepGoing)
                    break;
                ClientThread t = new ClientThread(socket);
                clients.add(t);
                t.start();
                if(!p2){
                    t.marker = "X";
                    t.sendObject("####X");
                    t.sendObject(boardState);
                    p2 = true;
                }
                else{
                    t.marker = "O";
                    t.sendObject("####O");
                    t.sendObject(boardState);
                }
                if(clients.size()==2){
                    keepGoing = false;
                    //startGame();
                }
                   
            }
        } catch (Exception e) {
            String msg = "Exception on new ServerSocket: " + e + "\n";
                System.out.println(""+msg);
        }
    }
    
    void startGame(){
        clients.forEach((ct) -> {
            ct.sendObject(boardState);
        });
    }
    public static void main(String argv[]) throws Exception {
        ServerClass sc = new ServerClass(1080);
        sc.start();
        
        
    }
    
    public boolean allTrue(boolean[] b){
        int count = 0;
        for(boolean i : b){
            if(i)
                count++;
        }
        if(count == b.length)
            return true;
        else
            return false;
    }
    
    boolean checkAndUpdateValidityState(String marker, Integer move){
        if(valid[move]){
            //update validity
            valid[move] = false;
            //update board
            System.out.println("Updating board for " + marker + " at " + move);
            boardState[move] = marker; 
            
            return true;
        }
        return false;
    }
    
    boolean checkIfWon(String marker){
        if(boardState[0].equalsIgnoreCase(marker) && boardState[1].equalsIgnoreCase(marker) && boardState[2].equalsIgnoreCase(marker))
            return true;
        if(boardState[3].equalsIgnoreCase(marker) && boardState[4].equalsIgnoreCase(marker) && boardState[5].equalsIgnoreCase(marker))
            return true;
        if(boardState[6].equalsIgnoreCase(marker) && boardState[7].equalsIgnoreCase(marker) && boardState[8].equalsIgnoreCase(marker))
            return true;
        if(boardState[0].equalsIgnoreCase(marker) && boardState[3].equalsIgnoreCase(marker) && boardState[6].equalsIgnoreCase(marker))
            return true;
        if(boardState[1].equalsIgnoreCase(marker) && boardState[4].equalsIgnoreCase(marker) && boardState[7].equalsIgnoreCase(marker))
            return true;
        if(boardState[2].equalsIgnoreCase(marker) && boardState[5].equalsIgnoreCase(marker) && boardState[8].equalsIgnoreCase(marker))
            return true;
        if(boardState[0].equalsIgnoreCase(marker) && boardState[4].equalsIgnoreCase(marker) && boardState[8].equalsIgnoreCase(marker))
            return true;
        if(boardState[6].equalsIgnoreCase(marker) && boardState[4].equalsIgnoreCase(marker) && boardState[2].equalsIgnoreCase(marker))
            return true;
        return false;
    }
    
    class ClientThread extends Thread {
        Socket socket;
        ObjectInputStream cInput;
        ObjectOutputStream cOutput;
        
        int connectionId;
        String marker;
        
        ClientThread(Socket socket) {
            connectionId = uniqueId++;
            this.socket = socket;
            try {
                cOutput = new ObjectOutputStream(socket.getOutputStream());
                cInput = new ObjectInputStream(socket.getInputStream());
            } catch (Exception e) {
                System.out.println("Error creating streams");
            }
        }
        
        public void run() {
            while(true) {
                try {
                    boolean wait = false;
                    Object obj = cInput.readObject();
                    if(currentTurn != connectionId)
                        sendObject("Not your turn nigga!!");
                    else if(obj instanceof Integer){
                        //check validity and update
                        if(!checkAndUpdateValidityState(marker, (Integer)obj)){
                            sendObject("Move is invalid");
                            wait = true;
                            //sendObject(boardState);
                        }
                        //board updated
                        //check if won
                        if(checkIfWon(marker))
                            sendObject("Launda jeet gya. Party!!");
                        
                        sendObject(boardState);
                        System.out.println("Board");
                        for(String s : boardState)
                            System.out.println(s);
                        
                    }
                    if(!wait){
                        if(currentTurn == 0)
                            currentTurn = 1;
                        else
                            currentTurn = 0;
                    }
                    wait = false;
                        
                } catch (IOException e) {
                    System.out.println("Error reading object from client " + connectionId);
                    close();
                    break;
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(ServerClass.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        
        private void close() {
            try {
                if(cOutput != null)
                    cOutput.close();
                if(cInput != null)
                    cInput.close();
                if(socket != null)
                    socket.close();
            } catch (Exception e) {
            }
        }
        
        public boolean sendObject(Object obj) {
            try {
                if(!socket.isConnected()) {
                    close();
                    return false;
                }
                System.out.println("Sending object " + obj.toString());
                cOutput.writeObject(obj);
            } catch (Exception e) {
                System.out.println("Error sending object to client " + connectionId);
                e.printStackTrace();
            }
            return true;
        }
    }
}
